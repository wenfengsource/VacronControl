/**
 * API build.
 */
#define IT9300_Version_CONTROL	0


/**
 * API version.
 */
#define IT9300_Version_NUMBER	3


/**
 * API date.
 */
#define IT9300_Version_DATE	20150925


/**
 * API build.
 */
#define IT9300_Version_BUILD	39
