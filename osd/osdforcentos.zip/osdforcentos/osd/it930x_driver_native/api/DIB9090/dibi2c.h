#ifndef ADAPTER_I2C_H
#define ADAPTER_I2C_H

#include "dibdatabus.h"

#endif
