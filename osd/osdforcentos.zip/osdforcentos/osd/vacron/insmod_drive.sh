#!/bin/sh -e

insmod /opt/vacron/tty_Virtual.ko
insmod /opt/vacron/usb-it930x.ko


