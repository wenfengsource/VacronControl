#!/bin/sh -e

insmod /opt/vacron/tty_Virtual.ko
insmod /opt/vacron/usb-it930x.ko
#export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/vacron
#/opt/vacron/vacron &

