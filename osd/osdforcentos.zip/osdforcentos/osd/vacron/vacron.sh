#!/bin/sh  
 
ARG=$1  
 
case   $ARG   in    
start):  
   /opt/vacron/vacron     &  
;;  
stop):  
pkill   vacron  
;;  
restart):  
pkill   vacron  
 /opt/vacron/vacron   & 
;;  

esac
