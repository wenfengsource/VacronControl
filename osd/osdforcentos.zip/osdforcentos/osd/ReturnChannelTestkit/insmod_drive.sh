#!/bin/sh -e

insmod /home/ubuntu/work/osd/it930x_driver_native/tty_Virtual.ko
insmod /home/ubuntu/work/osd/it930x_driver_native/usb-it930x.ko


